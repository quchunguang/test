/* 
 * Data encription standard header file for cipher.c
 */
#include "des.h"

#define makeKey		desMakeKey
#define encipher	des
#define decipher	des
#define	inBlockSize	desInBlockSize
#define	outBlockSize	desOutBlockSize
