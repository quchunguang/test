/*--- newdes.h -- Symbols for the NEWDES algorithm.
 *
 *   Mark Riordan   23 March 1991	Placed in the public domain.
 */

#define NEWDES_SIZE_KEY_UNRAV	 60

#define NEWDES_USER_KEY_BYTES	 15
#define NEWDES_BLOCK_BYTES		 8
