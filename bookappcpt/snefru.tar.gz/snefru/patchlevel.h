/*
**  Header file for Snefru package.
**  Based on the reference implementation (no algorithm changes) of
**  version 2.0, July 31, 1989.  Implementor:  Ralph C. Merkle.
**  This edition is by Rich $alz, <rsalz@bbn.com>.
**
**  $Log:	patchlevel.h,v $
**  Revision 1.1  90/03/22  13:34:53  rsalz
**  Initial revision
**  
**  $Header: patchlevel.h,v 1.1 90/03/22 13:34:53 rsalz Exp $
*/
#define PATCHLEVEL	0
